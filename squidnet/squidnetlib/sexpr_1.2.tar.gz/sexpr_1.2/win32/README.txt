This directory contains files kindly contributed by Brad Green to get the
library working under Visual Studio .NET 2003 for Windows.  Windows users 
who will use the library from cygwin should use it as described for Unix
systems like Linux and OSX.  Two subdirectories are under here:

  libsexpr/
  sexpr_test/

The libsexpr directory contains the project file for building the library
itself.  The sexpr_test directory contains a sample C++ test project that
uses the library.

This hasn't been tested with any other Visual Studio version other than the
.NET 2003 version.  It should serve as a starting point though to get you
started with other versions that may be incompatible with the project files
included here.

(3.15.2005)
